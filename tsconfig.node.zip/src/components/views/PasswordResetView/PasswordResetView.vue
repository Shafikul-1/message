<script setup lang="ts">
import ResetForm from "@src/components/views/PasswordResetView/PasswordResetForm.vue";
</script>

<template>
  <div>
    <div class="w-full h-screen flex">
      <ResetForm />
    </div>
  </div>
</template>
