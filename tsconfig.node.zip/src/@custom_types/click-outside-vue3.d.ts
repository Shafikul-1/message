declare module "click-outside-vue3";
