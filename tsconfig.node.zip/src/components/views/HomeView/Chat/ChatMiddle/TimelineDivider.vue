<script setup lang="ts">
import Typography from "@src/components/ui/data-display/Typography.vue";
</script>

<template>
  <div class="w-full my-7 flex items-center justify-center">
    <div
      class="w-full h-0 border-t border-dashed dark:border-gray-600 dark:bg-opacity-0"
    ></div>

    <Typography variant="body-4" class="mx-5"> Today </Typography>

    <div
      class="w-full h-0 border-t border-dashed dark:border-gray-600 dark:bg-opacity-0"
    ></div>
  </div>
</template>
