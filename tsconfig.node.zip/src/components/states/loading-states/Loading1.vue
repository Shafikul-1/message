<template>
  <div class="w-full flex px-5 py-6 mb-3">
    <div class="mr-4">
      <div
        class="w-7 h-7 rounded-full bg-gray-200 dark:bg-gray-600 animate-pulse"
      ></div>
    </div>

    <div class="grow">
      <div
        class="w-12 h-3 rounded-full bg-gray-200 dark:bg-gray-600 mb-4 animate-pulse"
      ></div>
      <div
        class="xs:w-full md:w-13 h-3 rounded-full bg-gray-200 dark:bg-gray-600 animate-pulse"
      ></div>
    </div>
  </div>
</template>
