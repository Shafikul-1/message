declare module "wavesurfer.js";
